//var wsUrl = "http://url.dominio/server.php?wsdl";//para probar de afuera.

var pictureSource;   // picture source
var destinationType; // sets the format of returned value
document.addEventListener("deviceready", onDeviceReady, false);

function showAlert(msj)
{
    navigator.notification.alert(
        msj,  // message
        'UNAB',   // title
        ''    // buttonName
    );
}//fin function mensaje.

// PhoneGap is ready
    function onDeviceReady() 
    {
		// Do cool things here...
		document.getElementById('largeImage').src='';
		clearCache();
		pictureSource=navigator.camera.PictureSourceType;
		destinationType=navigator.camera.DestinationType;
    }
    function clearCache() 
    {
		navigator.camera.cleanup();
	}
 
	function getImage(source) 
	{
	    // Retrieve image file location from specified source
		navigator.camera.getPicture(uploadPhoto, onFail, { quality: 50,
    destinationType: Camera.DestinationType.DATA_URL, sourceType: source});	//destinationType: navigator.camera.DestinationType.FILE_URI
	 
    }
    
    function onFail(message) {
    
    clearCache();
		//alert('Captura Descartada.');
		showAlert('Captura Descartada.'+ message);
			
}
 
    function uploadPhoto(imageURI) 
    {
	  var largeImage = document.getElementById('largeImage');
	    largeImage.style.display = 'block';
	    largeImage.src ="data:image/jpeg;base64," + imageURI;
	    
    }
    
   
function enviaFoto()
{
	var user=document.getElementById('user').value;
	//var foto=document.getElementById('largeImage');
	var fotoSrc=document.getElementById('largeImage').src;
	
	if(user=='' || fotoSrc=='')
	{
		showAlert('Debe Ingresar los valores!');
	}
	else
	{
	  //var fotoCod=encodeImageFileAsURL(foto);

            $.ajax({
            cache: false,
            // puede ser GET, POST
            type: "POST",  							
            // Tipo de retorno
            dataType: "html",
            // pagina php que recibe la llamada
            url: "http://72.14.183.67/ws/foto.php",  							
            // datos, ej: $_POST['data']
            data: {
                    user:user,
                    foto:fotoSrc				
            },
            /*beforeSend: function(){  
                document.getElementById('divCargando').style.display="block";
                $("#labelCargando").html('Cargando...');	
            },*/
            // acciones cuando me retorna algo el PHP
            success: function( msg){
                   console.log(msg);
                    if(msg=='1')
                    {
                        showAlert('Ha ocurrido un Error. Archivo ya existe!');
                    }
                    else
                    {
                        showAlert('Foto Subida!.');

                    }
            },							
            // acciones cuando hay error en comunicacion el el php
            error: function(xhr, status,msg2 ){
                    //alert('4');			
                    console.log(xhr);
            }
            });//fin ajax
	
        }
}
function mapa(){
        var option = {
  enableHighAccuracy: true // use GPS as much as possible
};
plugin.google.maps.LocationService.getMyLocation(option, function(location) {

  // Create a map with the device location
  var mapDiv = document.getElementById('map_canvas');
  var map = plugin.google.maps.Map.getMap(mapDiv, {
    'camera': {
      target: location.latLng,
      zoom: 16
    }
  });


  // Add a marker
  var text = ["Current your location:\n",
    "latitude:" + location.latLng.lat.toFixed(3),
    "longitude:" + location.latLng.lng.toFixed(3),
    "speed:" + location.speed,
    "time:" + location.time,
    "bearing:" + location.bearing].join("\n");

  var marker = map.addMarker({
    title: text,
    position: location.latLng
  });

  marker.showInfoWindow();

});
}

function enviar(){
    alert("entro a la funcion");
      var option = {
  enableHighAccuracy: true // use GPS as much as possible
};
plugin.google.maps.LocationService.getMyLocation(option, function(location) {
    var lat = location.latLng.lat.toFixed(3);
    var lon = location.latLng.lng.toFixed(3);
    alert("latitud");
    alert(lat);
    ajaxx(lat,lon);

});

}


function ajaxx(lat, lon){
    alert("entro a la 2 function");
    var fotoSrc=document.getElementById('largeImage').src;
    var nombres = document.getElementById("nombres").value;
    var apellidos = document.getElementById("apellidos").value;
    var rut = document.getElementById("rut").value;
    var edad = document.getElementById("edad").value;
    var sexo = document.getElementById("sexo").value;
    var email = document.getElementById("email").value;
    var fono = document.getElementById("fono").value;
    var carrera = document.getElementById("carrera").value;
    var posicion = lat+","+lon;
    var fecha = "2018-06-12";
    alert("leo los datos");
            alert("entro al ajax");
            $.ajax({
            cache: false,
            // puede ser GET, POST
            type: "POST",                           
            // Tipo de retorno
            dataType: "json",
            // pagina php que recibe la llamada
            url: "http://72.14.183.67/ws/s2/perfil.php",                             
            // datos, ej: $_POST['data']
            data: {
                    foto:fotoSrc,
                    nombres:nombres,
                    apellidos:apellidos,
                    rut:rut,
                    edad:edad,
                    sexo:sexo,
                    email:email,
                    fono:fono,
                    carrera:carrera,
                    coordenadas: posicion,
                    fecha_creacion: fecha

            },
            /*beforeSend: function(){  
                document.getElementById('divCargando').style.display="block";
                $("#labelCargando").html('Cargando...');    
            },*/
            // acciones cuando me retorna algo el PHP
            success: function( json){
                   alert(json.estado);

            }
            });//fin ajax
            alert("termina ajax");
    

}

function guardar(){
    var foto = document.getElementById("user").value;
    var nombres = document.getElementById("nombres").value;
    var apellidos = document.getElementById("apellidos").value;
    var rut = document.getElementById("rut").value;
    var edad = document.getElementById("edad").value;
    var sexo = document.getElementById("sexo").value;
    var email = document.getElementById("email").value;
    var fono = document.getElementById("fono").value;
    var carrera = document.getElementById("carrera").value;
    var db = sqlitePlugin.openDatabase('usuarios.db', '1.0', '', 1);
        db.transaction(function (txn) {
            txn.executeSql('CREATE TABLE IF NOT EXISTS usuarios (id integer primary key AUTOINCREMENT, foto blob, nombres VARCHAR(100), apellidos VARCHAR(100), edad INT(3), rut VARCHAR(25), sexo VARCHAR(1), email VARCHAR(50), fono VARCHAR(25), carrera VARCHAR(100), fecha_creacion DATETIME DEFAULT CURRENT_TIMESTAMP)');
            txn.executeSql('INSERT INTO usuarios (id, foto,nombres,apellidos,edad,rut,sexo,email,fono,carrera,fecha_creacion) VALUES (?,?,?,?,?,?,?,?,?,?,?)', ["", "foto","nombres","apellidos","edad","rut","sexo","email","fono","carrera","fecha_creacion"]);
  
        });
}

function crearqr(){
    var rut = document.getElementById("rut").value;
    var url = "http://72.14.183.67/ws/s2/archivos/"+rut+".html";
    $.ajax({

            cache: false,
            // puede ser GET, POST
            type: "POST",                           
            // Tipo de retorno
            dataType: "json",
            // pagina php que recibe la llamada
            url: "http://72.14.183.67/ws/s2/qr.php",                             
            // datos, ej: $_POST['data']
            data: {
                    user:rut,
                    qr: url

            },
            /*beforeSend: function(){  
                document.getElementById('divCargando').style.display="block";
                $("#labelCargando").html('Cargando...');    
            },*/
            // acciones cuando me retorna algo el PHP
            success: function( json){
                   alert(json.estado);

            }
            });//fin ajax
}








